import { createApp } from 'vue'
// import App from './App.vue'
import wrapper from './wrapper.vue'

createApp(wrapper).mount('#app')
