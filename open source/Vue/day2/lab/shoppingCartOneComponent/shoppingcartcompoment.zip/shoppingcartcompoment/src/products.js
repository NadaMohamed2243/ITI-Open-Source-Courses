export default[
    {
        id:100,
        name:'product One',
        price:1000,
        instock:5,
        description:"product One is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
        image:'https://media.istockphoto.com/id/946995676/photo/sorano-a-town-built-on-a-tuff-rock-is-one-of-the-most-beautiful-villages-in-italy.jpg?s=612x612&w=0&k=20&c=w0rc8jZUHE-i9Q61ltd1lAN4oZvZZNoENvAjrdkRF-w='
    },
    {
        id:200,
        name:'product Two',
        price:2000,
        instock:15,
        description:"product Two is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
        image:'https://media.istockphoto.com/id/1216933848/photo/pitigliano-a-town-built-on-a-tuff-rock-is-one-of-the-most-beautiful-villages-in-italy.jpg?s=612x612&w=0&k=20&c=T6pGSjPjaOjtw_Ie4hSqYRHc1ttMXnRgduR4fSlegc4='
    },
    {
        id:300,
        name:'product Three',
        price:3000,
        instock:500,
        description:"product Three is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
        image:'https://media.istockphoto.com/id/909706328/photo/laptop-with-alarm-clock.jpg?s=612x612&w=0&k=20&c=B23aJ_QrzqUP_1B346ZzvUQT6yJoQwqPj5nx_obJlQE='
    },
    {
        id:400,
        name:'product Four',
        price:4000,
        instock:800,
        description:"product Four is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
        image:'https://media.istockphoto.com/id/909349570/photo/home-interior-modern-beautiful-apartment.jpg?s=612x612&w=0&k=20&c=tC0Vn7oMvqBH13xQiZ4BFXZyApdCuldcPYQEqX4WwLg='
    },
    {
        id:500,
        name:'product Five',
        price:5000,
        instock:0,
        description:"product Five is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
        image:'https://media.istockphoto.com/id/909908494/photo/kids-playing-tag-in-mediterranean-street.jpg?s=612x612&w=0&k=20&c=keOd4NxEFeZQwglAaDzx-cz6CCeuuODdo47qlvKFGeU='
    },
    {
        id:600,
        name:'product Six',
        price:6000,
        instock:3,
        description:"product Six is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
        image:'https://media.istockphoto.com/id/911608814/photo/driving-in-the-fog.jpg?s=612x612&w=0&k=20&c=J1b-WmgLt3cJPWp6o4QklUKaek9I0fY0nj9saQAXnF0='
    }
];