<template>
    <div class="container p-1">
      <!-- navbar -->
      <div class="d-flex justify-content-between align-items-baseline p-2 m-2 bg-dark text-light rounded">
        <a href="#" style="color:rgb(255, 170, 0);text-decoration: none;" @click.prevent="isCartVisible = false">
          Products
        </a>
        <div class="d-flex align-items-baseline">
          <p class="px-2 mx-2">
            {{ cart.items.length }} <span v-if="cart.items.length == 1">item</span>
            <span v-else>items</span> with total {{ formatCurrency(getTotalPrice()) }}
          </p>
          <button class="btn btn-primary" @click="isCartVisible = true">Show Cart</button>
        </div>
      </div>
      <!-- end of navbar -->
  
      <!-- products -->
      <div class="row justify-content-center" v-if="!isCartVisible">
        <div v-for="product in products" :key="product.id" class="card" style="width: 23rem; margin: 0.2rem;">
          <img :src="product.image" :title="product.name" :alt="product.name" />
          <h4 class="w-100 text-center my-2">{{ product.name }}</h4>
          <p style="text-align: justify">{{ product.description }}</p>
          <div class="card-footer">
            <div class="d-flex justify-content-between align-items-baseline">
              <p :class="[product.instock >= 5 ? 'more' : '', product.instock < 5 ? 'less' : '', product.instock == 0 ? 'zero' : '']">
                Instock: {{ product.instock }}
              </p>
              <p>Price: {{ formatCurrency(product.price) }}</p>
              <button class="btn btn-primary" :disabled="product.instock == 0" @click="addToCart(product)">
                Add To Cart
              </button>
            </div>
          </div>
        </div>
      </div>
  
      <!-- cart -->
      <div v-else>
        <h4 class="w-100 text-center text-danger py-2" v-if="cart.items.length == 0">
          Sorry, No Items found, please Add!!!
        </h4>
        <div v-else>
          <table class="table table-striped table-bordered text-center">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total Price</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in cart.items" :key="item.product.id">
                <td>{{ item.product.id }}</td>
                <td>{{ item.product.name }}</td>
                <td>{{ item.quantity }}</td>
                <td>{{ formatCurrency(item.product.price) }}</td>
                <td>{{ formatCurrency(item.product.price * item.quantity) }}</td>
                <td>
                  <button class="btn btn-success mx-3" :disabled="item.product.instock == 0" @click="increaseQuantity(item)">
                    +
                  </button>
                  |
                  <button class="btn btn-danger mx-3" @click="decreaseQuantity(item)">-</button>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th colspan="3">Total Price</th>
                <th colspan="3">{{ formatCurrency(getTotalPrice()) }}</th>
              </tr>
              <tr>
                <th colspan="3">Total Taxes</th>
                <th colspan="3">{{ formatCurrency(getTotalPrice() * 0.1) }}</th>
              </tr>
              <tr>
                <th colspan="3">Total</th>
                <th colspan="3">{{ formatCurrency(getTotalPrice() + getTotalPrice() * 0.1) }}</th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import products from './products.js';
  
  export default {
    data() {
      return {
        products: products,
        isCartVisible: false,
        cart: {
          items: [],
        },
      };
    },
    methods: {
      isProductExist(product) {
        return this.cart.items.some((item) => item.product.id == product.id);
      },
      addToCart(product) {
        if (!this.isProductExist(product)) {
          this.cart.items.push({ product: product, quantity: 1 });
        } else {
          this.cart.items.find((item) => item.product.id == product.id).quantity++;
        }
        product.instock--;
      },
      getTotalPrice() {
        return this.cart.items.reduce((total, item) => total + item.quantity * item.product.price, 0);
      },
      increaseQuantity(item) {
        item.quantity++;
        item.product.instock--;
      },
      decreaseQuantity(item) {
        item.quantity--;
        if (item.quantity == 0) {
          this.cart.items.splice(this.cart.items.findIndex((i) => i.product.id == item.product.id), 1);
        }
        item.product.instock++;
      },
      formatCurrency(value) {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 0,
        }).format(value);
      },
    },
  };
  </script>
  
  <style>
  .more,
  .less,
  .zero {
    font-weight: bold;
  }
  
  .more {
    color: green;
  }
  
  .less {
    color: orange;
  }
  
  .zero {
    color: red;
  }
  </style>