<template>
    <div class="container my-2">
        <div class="row my-2">
            <!-- single value -->
            <!-- <Header track="open source"/> -->

            <!-- muliple values -->
                <!-- seperate properites -->
                <!-- in header you can define prop for each value -->
            <!-- <Header track="open source" branch="Mansoura" locationcity="Mansouraunivercity"/> -->
                <!-- properity with an obj -->
                <!-- you have to bind the obj -->
            <Header :intake="{track:'open source',branch:'Mansoura',locationcity:'Mansouraunivercity'}">
                <!-- <a href="#">More...</a> -->
                 <template v-slot:button>
                    <a href="#">More...</a>
                 </template>
                 <template v-slot:top>
                    <a href="#">hello</a>
                 </template>
                 <h5>os</h5>
            </Header>
        </div><!--end of row 1-->

        <div class="row my-2">
            <div class="col-2">
                <Links/>
            </div>
            <div class="col-9 offset-1">
                <Body/>
            </div>
        </div><!--end of row 2-->

        <div class="row my-2">
            <Footer/>
        </div><!--end of row 2-->

    </div> <!--end of container-->
</template>

<script>
import Header from '@/components/HeaderComponent.vue'
import Footer from '@/components/FooterComponent.vue'
import Links from '@/components/LinksComponent.vue'
import Body from '@/components/BodyComponent.vue'
export default {
    components:{
        Header,
        Footer,
        Links,
        Body
    }     
}
</script>

<style>

</style>