<template>
    <div>
        <ul class="list-group">
            <li class="list-group-item">Home</li>
            <li class="list-group-item active">Contact</li>
            <li class="list-group-item">About</li>
        </ul>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>