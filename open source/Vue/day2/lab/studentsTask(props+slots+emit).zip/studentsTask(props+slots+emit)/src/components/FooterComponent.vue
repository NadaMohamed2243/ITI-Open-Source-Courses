<template>
    <div>
        <h4 class="w-100 text-center py-3 bg-warning">Footer</h4>
        <span>Goodbye</span>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
/* without (scoped) all span all over the project will be afected */
span{
    color: red;
}

</style>