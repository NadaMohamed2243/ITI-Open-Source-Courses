<template>
    <div>
        <button class="btn btn-primary w-100 mb-1" @click="sendNewStd">Add</button>
    </div>
</template>

<script>
import students from '@/students';

export default {
    methods:{
        sendNewStd(){
            // raise event : using --> $emit("addbtnclicked")
            this.$emit("addbtnclicked",{name:"testname",city:"testcity"});
        }
    }
}
</script>

<style>

</style>