<template>
    <div>
        <add @addbtnclicked="addNewStd"/>
        <table class="table table-striped table-border text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>City</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="student in students" :key="student.id">
                    <td>{{student.id}}</td>
                    <td>{{ student.name }}</td>
                    <td>{{ student.city }}</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">Number of students {{ students.length }}</td>
                </tr>
            </tfoot>
        </table>
    </div>
</template>

<script>
import students from '@/students.js'
import add from '@/components/AddComponents.vue'
export default {
    components:{
        add
    },
    data(){
        return{ 
            students:students
        }
    },
    methods:{
        addNewStd(_data){
            console.log("add clicked from body",_data.name)
            this.students.push({id:this.students[this.students.length-1].id+1,name:_data.name,city:_data.city})
        }
    }
}
</script>

<style>

</style>