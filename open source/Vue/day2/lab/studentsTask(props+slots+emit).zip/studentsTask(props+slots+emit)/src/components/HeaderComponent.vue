<template>
    <div>
        <slot name="top"/>
        <!-- <h4 class="w-100 text-center py-3 bg-info">Header <br/> your track is {{ track }} </h4> -->
        <h4 class="w-100 text-center py-3 bg-info">Header <br/> your track is {{ intake.track }} <br/> your branch is {{ intake.branch }} <br/> your location is {{ intake.locationcity }}</h4>
        <!-- default slot -->
        <!-- <slot/> -->
        <!-- named slot -->
        <slot name="button"/>
        <!-- default contain  -->
        <slot>
            <p>course name : vue</p>
        </slot>
    </div>
</template>

<script>
// properites will be mounted as a data
export default {
    // props:["track"]
    props:["intake"]
}
</script>

<style>

</style>