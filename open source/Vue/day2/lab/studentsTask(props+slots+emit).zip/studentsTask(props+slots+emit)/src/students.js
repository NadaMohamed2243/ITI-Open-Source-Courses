export default[
    { id: 1, name: "Ahmed", city: "Cairo" },
    { id: 2, name: "Nada", city: "Alexandria" },
    { id: 3, name: "Omar", city: "Giza" },
    { id: 4, name: "Mona", city: "Mansoura" },
    { id: 5, name: "Youssef", city: "Tanta" }
]