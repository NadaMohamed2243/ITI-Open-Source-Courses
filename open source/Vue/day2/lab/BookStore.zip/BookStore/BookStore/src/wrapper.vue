<template>
  <div class="container my-2">
    <div>
      <h3 class="text-center bg-light text-info-emphasis rounded">
        Our Book Store
      </h3>
    </div>

    <!-- book list -->
    <div class="my-3">
      <booklists :books="books" />
    </div>

    <!-- book cart -->
    <div class="my-3">
      <bookcart :books="books" @add-to-wishlist="addToWishlist" />
    </div>

    <!-- wish list -->
    <div class="my-4">
      <wishlist :wishlist="wishlist" @remove-from-wishlist="removeFromWishlist" />
    </div>
  </div>
</template>

<script>
import books from "@/books.js";
import booklists from "./components/booklists.vue";
import bookcart from "./components/bookcart.vue";
import wishlist from "./components/wishlist.vue";

export default {
  data() {
    return {
      books: books,
      wishlist: []
    };
  },
  components: {
    booklists,
    bookcart,
    wishlist
  },
  methods: {
    addToWishlist(book) {
      if (!this.wishlist.find(b => b.ISBN === book.ISBN)) {
        this.wishlist.push(book);
      }
    },
    removeFromWishlist(ISBN) {
      this.wishlist = this.wishlist.filter(book => book.ISBN !== ISBN);
    }
  }
};
</script>

<style></style>