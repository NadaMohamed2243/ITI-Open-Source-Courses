export default [
    {
        ISBN: "978-1-891830-77-8",
        name: "JavaScript: The Good Parts",
        category: "Programming",
        image: "js.jpg",
        pages: 176,
        author: "Douglas Crockford",
        price: 120
    },
    {
        ISBN: "978-0-13-235088-4",
        name: "Clean Code",
        category: "Software Engineering",
        image: "cc.jpg",
        pages: 464,
        author: "Robert C. Martin",
        price: 180
    },
    {
        ISBN: "978-1-59327-584-6",
        name: "Eloquent JavaScript",
        category: "Programming",
        image: "jss.jpg",
        pages: 48,
        author: "Marijn Haverbeke",
        price: 95
    },
    {
        ISBN: "978-1-891830-77-81",
        name: "JavaScript: The Good Parts",
        category: "Programming",
        image: "js.jpg",
        pages: 176,
        author: "Douglas Crockford",
        price: 120
    },
    {
        ISBN: "978-0-13-235088-41",
        name: "Clean Code",
        category: "Software Engineering",
        image: "cc.jpg",
        pages: 464,
        author: "Robert C. Martin",
        price: 180
    },
    {
        ISBN: "978-1-59327-584-61",
        name: "Eloquent JavaScript",
        category: "Programming",
        image: "jss.jpg",
        pages: 48,
        author: "Marijn Haverbeke",
        price: 95
    }
]
