<template>
    <div class="row gap-3 justify-content-center">
      <h5 class="text-info-emphasis">Book Cart</h5>
      <div :class="['card', 'col-md-4', 'mb-4', book.pages < 50 ? 'less' : 'more']" style="width: 18rem"
           v-for="book in books" :key="book.ISBN">
        <img :src="getImagePath(book.image)" class="card-img-top" alt="Book Image" height="338" width="263" />
        <div class="card-body">
          <h5 class="card-title">
            <span class="text-info-emphasis">{{ book.name }}</span>
          </h5>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item text-info-emphasis">
            <span class="fw-bold">Author :</span> {{ book.author }}
          </li>
          <li class="list-group-item text-info-emphasis">
            <span class="fw-bold">Category :</span> {{ book.category }}
          </li>
          <li class="list-group-item text-info-emphasis">
            <span class="fw-bold">ISBN :</span> {{ book.ISBN }}
          </li>
          <li class="list-group-item text-info-emphasis">
            <span class="fw-bold">Number Of Pages :</span> {{ book.pages }}
            <span v-if="book.pages == 1">page</span> <span v-else>pages</span>
          </li>
          <li class="list-group-item text-info-emphasis">
            <span class="fw-bold">Price : </span>{{ formatPrice(book.price) }}
          </li>
        </ul>
        <div class="card-body">
          <button class="btn btn-info w-100" @click="addToWishlist(book)">
            Add to Wishlist
          </button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    methods: {
      formatPrice(price) {
        return new Intl.NumberFormat("ar-SA", {
          style: "currency",
          currency: "SAR",
        }).format(price);
      },
      getImagePath(imagePath) {
        try {
          return require(`@/assets/${imagePath}`);
        } catch (e) {
          return e;
        }
      },
      addToWishlist(book) {
        this.$emit('add-to-wishlist', book);
      }
    },
    props: ["books"],
  };
  </script>
  
  <style scoped>
  .less {
    border: 2px solid red;
  }
  
  .more {
    border: 2px solid green;
  }
  </style>