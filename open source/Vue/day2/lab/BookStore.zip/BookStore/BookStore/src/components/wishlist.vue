<template>
    <div>
      <h5 class="text-info-emphasis">Wishlist</h5>
  
      <h5 class="text-info-emphasis text-center py-3 bg-light" v-if="wishlist.length == 0">
        No Books in your Wishlist
      </h5>
      <table class="table" v-else>
        <thead>
          <tr>
            <th>Name</th>
            <th>Author</th>
            <th>Category</th>
            <th>Price</th>
            <th>ISBN</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="book in wishlist" :key="book.ISBN">
            <td>{{ book.name }}</td>
            <td>{{ book.author }}</td>
            <td>{{ book.category }}</td>
            <td>{{ formatPrice(book.price) }}</td>
            <td>{{ book.ISBN }}</td>
            <td>
              <button class="btn btn-danger btn-sm" @click="removeFromWishlist(book.ISBN)">
                Remove
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  export default {
    props: ["wishlist"],
    methods: {
      formatPrice(price) {
        return new Intl.NumberFormat("ar-SA", {
          style: "currency",
          currency: "SAR",
        }).format(price);
      },
      removeFromWishlist(ISBN) {
        this.$emit('remove-from-wishlist', ISBN);
      }
    },
  };
  </script>
  
  <style></style>