<template>
  <div>
    <h5 class="text-info-emphasis">Book List</h5>
    <ul class="list-group" v-for="book in books" :key="book.ISBN">
      <li class="list-group-item list-group-item-action list-group-item-info" :title=" book.author">{{book.name}}</li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["books"],
  // mounted() {
  //     console.log(this.books[0]);
  // }
};
</script>

<style></style>

<!-- --------------------------------------------- -->